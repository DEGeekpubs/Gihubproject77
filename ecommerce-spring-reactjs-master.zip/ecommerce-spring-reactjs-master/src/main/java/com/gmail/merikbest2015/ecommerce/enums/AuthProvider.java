package com.gmail.merikbest2015.ecommerce.enums;

public enum AuthProvider {
    LOCAL, GOOGLE, GITHUB, FACEBOOK
}
