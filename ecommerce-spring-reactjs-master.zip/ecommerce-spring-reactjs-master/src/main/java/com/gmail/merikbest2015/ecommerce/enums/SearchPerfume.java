package com.gmail.merikbest2015.ecommerce.enums;

public enum SearchPerfume {
    BRAND, PERFUME_TITLE, COUNTRY
}
