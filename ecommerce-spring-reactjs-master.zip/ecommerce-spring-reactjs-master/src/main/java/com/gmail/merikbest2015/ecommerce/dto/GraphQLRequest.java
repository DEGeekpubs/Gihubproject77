package com.gmail.merikbest2015.ecommerce.dto;

import lombok.Data;

@Data
public class GraphQLRequest {
    private String query;
}
