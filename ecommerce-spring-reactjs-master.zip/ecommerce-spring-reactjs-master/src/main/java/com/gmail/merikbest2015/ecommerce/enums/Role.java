package com.gmail.merikbest2015.ecommerce.enums;

public enum Role {
    USER, ADMIN
}
