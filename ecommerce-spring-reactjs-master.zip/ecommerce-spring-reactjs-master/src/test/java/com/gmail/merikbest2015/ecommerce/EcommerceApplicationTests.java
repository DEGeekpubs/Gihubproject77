package com.gmail.merikbest2015.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    public void main() {
        EcommerceApplication.main(new String[] {});
    }
}
